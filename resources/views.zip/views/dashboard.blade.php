@extends('layouts.backend')

@php
    $gnf = fn ($m) => number_format((float) $m, 0, ',', ' ');
    $etablissement = \App\Support\Etablissement\IdentiteDocument::courante();
    $maxSemaine = max(1, $semaine->max('consultations'));
@endphp

@section('style')
<style>
    /* Le tableau de bord parle d'AUJOURD'HUI : la journée occupe le haut de
       l'écran, le reste vient après. */
    .kpi { border: 1px solid var(--hali-bordure, #e5e7eb); border-radius: 12px; background: #fff; padding: 1rem 1.1rem; height: 100%; }
    .kpi-libelle { font-size: .72rem; text-transform: uppercase; letter-spacing: .06em; color: #6b7280; font-weight: 700; margin: 0; }
    .kpi-valeur { font-size: 1.75rem; font-weight: 650; color: #111827; line-height: 1.15; margin: .15rem 0 0; }
    .kpi-detail { font-size: .78rem; color: #6b7280; margin: .15rem 0 0; }
    .kpi-accent { border-left: 4px solid var(--hali-primaire, #0f766e); }
    .kpi-alerte { border-left: 4px solid #b45309; }

    .barre-jour { display: flex; flex-direction: column; align-items: center; gap: .35rem; flex: 1; }
    .barre-jour .tige { width: 100%; max-width: 34px; background: var(--hali-primaire-clair, #ccfbf1); border-radius: 6px 6px 0 0; min-height: 4px; }
    .barre-jour .tige.forte { background: var(--hali-primaire, #0f766e); }
    .barre-jour small { color: #6b7280; font-size: .7rem; }

    .ligne-attente { display: flex; align-items: center; gap: .75rem; padding: .7rem 0; border-top: 1px solid #f1f2f4; }
    .ligne-attente:first-child { border-top: none; }
    .rang { width: 26px; height: 26px; border-radius: 50%; background: #f3f4f6; color: #374151; font-size: .78rem; font-weight: 700; display: flex; align-items: center; justify-content: center; flex: none; }
    .rang.urgence { background: #fef2f2; color: #b91c1c; }
</style>
@endsection

@section('content')
<div class="container"><div class="page-inner">

    {{-- ---------------------------------------------------------- En-tête --}}
    <div class="page-header d-flex flex-wrap align-items-center gap-2">
        <div>
            <h3 class="fw-bold mb-0">{{ $etablissement->nom }}</h3>
            <div class="small text-muted">{{ ucfirst(now()->translatedFormat('l d F Y')) }} — journée en cours</div>
        </div>
        <div class="ms-auto d-flex flex-wrap gap-2">
            @can('parcours.accueil')
                <a href="{{ route('parcours.accueil.index') }}" class="btn btn-primary btn-sm"><i class="fa fa-door-open"></i> Accueil du jour</a>
            @endcan
            @can('patient.view')
                <a href="{{ route('patient.index') }}" class="btn btn-secondary btn-sm">Patients</a>
            @endcan
            @can('rapports.view')
                <a href="{{ route('rapports.index') }}" class="btn btn-secondary btn-sm">Rapports</a>
            @endcan
        </div>
    </div>

    {{-- ---------------------------------------------------------- La journée --}}
    <div class="row g-3 mb-3">
        <div class="col-6 col-lg-3">
            <div class="kpi kpi-accent">
                <p class="kpi-libelle">Patients reçus</p>
                <p class="kpi-valeur">{{ $visites->count() }}</p>
                <p class="kpi-detail">{{ $terminees }} vus · {{ $enAttente->count() }} en attente</p>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="kpi {{ ($attenteMoyenne ?? 0) > 45 ? 'kpi-alerte' : '' }}">
                <p class="kpi-libelle">Attente moyenne</p>
                <p class="kpi-valeur">{{ $attenteMoyenne !== null ? $attenteMoyenne . ' min' : '—' }}</p>
                <p class="kpi-detail">{{ $enConsultation->count() }} en consultation</p>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="kpi">
                <p class="kpi-libelle">Encaissé aujourd'hui</p>
                <p class="kpi-valeur">{{ $gnf($encaisseCejour) }}</p>
                <p class="kpi-detail">GNF</p>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="kpi {{ $resteAEncaisser > 0 ? 'kpi-alerte' : '' }}">
                <p class="kpi-libelle">Reste à encaisser</p>
                <p class="kpi-valeur">{{ $gnf($resteAEncaisser) }}</p>
                <p class="kpi-detail">sur les factures du jour</p>
            </div>
        </div>
    </div>

    <div class="row">
        {{-- ------------------------------------------------ File d'attente --}}
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Salle d'attente <span class="badge badge-warning">{{ $enAttente->count() }}</span></h4>
                    @can('parcours.accueil')
                        <a href="{{ route('parcours.accueil.index') }}" class="ms-auto small">Ouvrir l'accueil</a>
                    @endcan
                </div>
                <div class="card-body">
                    @forelse($enAttente->take(8) as $index => $visite)
                        <div class="ligne-attente">
                            <span class="rang {{ $visite->urgence ? 'urgence' : '' }}">{{ $index + 1 }}</span>
                            <div class="flex-grow-1">
                                <div class="fw-semibold">{{ $visite->patient?->full_name }}</div>
                                <div class="small text-muted">
                                    {{ $visite->motif ?: 'Consultation' }}
                                    @if($visite->medecin) · {{ $visite->medecin->nom_affiche }} @endif
                                </div>
                            </div>
                            <div class="text-end small">
                                <div class="text-muted">{{ $visite->arrivee_le->format('H:i') }}</div>
                                <div class="{{ $visite->minutesAttente() > 45 ? 'text-danger fw-semibold' : 'text-muted' }}">{{ $visite->minutesAttente() }} min</div>
                            </div>
                        </div>
                    @empty
                        <p class="text-muted text-center py-4 mb-0">Personne n'attend. Bonne journée.</p>
                    @endforelse

                    @if($enAttente->count() > 8)
                        <div class="small text-muted mt-2">et {{ $enAttente->count() - 8 }} autre(s)…</div>
                    @endif
                </div>
            </div>

            {{-- ------------------------------------------------ Semaine --}}
            <div class="card">
                <div class="card-header"><h4 class="card-title">Consultations des 7 derniers jours</h4></div>
                <div class="card-body">
                    <div class="d-flex align-items-end gap-2" style="height: 120px">
                        @foreach($semaine as $jour)
                            <div class="barre-jour">
                                <span class="small fw-semibold">{{ $jour['consultations'] }}</span>
                                <div class="tige {{ $jour['date']->isToday() ? 'forte' : '' }}"
                                     style="height: {{ max(4, (int) ($jour['consultations'] / $maxSemaine * 80)) }}px"></div>
                                <small>{{ ucfirst($jour['date']->translatedFormat('D')) }}</small>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        {{-- ------------------------------------------------ Rendez-vous --}}
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Rendez-vous du jour <span class="badge badge-light">{{ $rdvDuJour->count() }}</span></h4>
                    @can('medecin.appointments')
                        <a href="{{ route('medecin.appointments') }}" class="ms-auto small">Agenda</a>
                    @endcan
                </div>
                <ul class="list-group list-group-flush small">
                    @forelse($rdvDuJour->take(8) as $rdv)
                        <li class="list-group-item d-flex align-items-center gap-2">
                            <span class="fw-semibold" style="width:46px">{{ \Illuminate\Support\Str::substr($rdv->appointment_time, 0, 5) }}</span>
                            <span class="flex-grow-1">
                                {{ $rdv->patient?->full_name }}
                                <div class="text-muted">{{ $rdv->motifRdv?->nom ?? 'Consultation' }}</div>
                            </span>
                            <span class="badge badge-{{ match($rdv->status) {
                                'completed' => 'success', 'no_show' => 'danger', 'cancelled' => 'secondary', default => 'info' } }}">
                                {{ match($rdv->status) {
                                    'completed' => 'Honoré', 'no_show' => 'Absent', 'cancelled' => 'Annulé',
                                    'confirmed' => 'Confirmé', default => 'À confirmer' } }}
                            </span>
                        </li>
                    @empty
                        <li class="list-group-item text-muted text-center py-4">Aucun rendez-vous aujourd'hui.</li>
                    @endforelse
                </ul>
                @if($rdvAbsents > 0)
                    <div class="card-footer small">{{ $rdvHonores }} honoré(s), <span class="text-danger">{{ $rdvAbsents }} absent(s)</span></div>
                @endif
            </div>
        </div>

        {{-- ------------------------------------------------ À surveiller --}}
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header"><h4 class="card-title">À surveiller</h4></div>
                <ul class="list-group list-group-flush small">
                    @can('assurance.creances.view')
                        <li class="list-group-item">
                            <a href="{{ route('assurance.creances.index') }}" class="d-flex justify-content-between">
                                <span>Dû par les assurances</span>
                                <strong>{{ $gnf($creancesAssurance) }}</strong>
                            </a>
                            @if($reclamationsAEnvoyer > 0)
                                <div class="text-muted">{{ $reclamationsAEnvoyer }} réclamation(s) à envoyer</div>
                            @endif
                        </li>
                    @endcan

                    @module('hospitalisation')
                        @can('hospitalisation.view')
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Hospitalisés</span>
                                <strong>{{ $hospitalisesActifs }}</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Chambres libres</span>
                                <strong>{{ $chambresLibres }}</strong>
                            </li>
                        @endcan
                    @endmodule

                    @module('laboratoire')
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Analyses en cours</span>
                            <strong>{{ $laboEnCours }}</strong>
                        </li>
                    @endmodule

                    <li class="list-group-item d-flex justify-content-between">
                        <span>Nouveaux patients</span>
                        <strong>{{ $nouveauxPatients }}</strong>
                    </li>
                </ul>
            </div>

            <div class="card">
                <div class="card-header"><h4 class="card-title">Derniers patients</h4></div>
                <ul class="list-group list-group-flush small">
                    @forelse($derniersPatients as $patient)
                        <li class="list-group-item">
                            <div class="fw-semibold">
                                @can('parcours.dossier')
                                    <a href="{{ route('parcours.dossier.show', $patient->id) }}">{{ $patient->full_name }}</a>
                                @else
                                    {{ $patient->full_name }}
                                @endcan
                            </div>
                            <div class="text-muted">{{ $patient->gender }}@if($patient->age !== null) · {{ $patient->age }} ans @endif</div>
                        </li>
                    @empty
                        <li class="list-group-item text-muted">Aucun patient enregistré.</li>
                    @endforelse
                </ul>
            </div>
        </div>
    </div>

</div></div>
@endsection
