@extends('layouts.backend')

@section('style')
<style>
    /* Une file d'attente se lit en diagonale : le suivant en haut, en grand,
       avec une seule action possible. Le reste s'efface. */
    .patient-suivant {
        border: 1px solid #0f766e;
        border-left: 5px solid #0f766e;
        background: #f0fdfa;
    }
    .patient-urgence { border-left: 5px solid #b91c1c; background: #fef2f2; }

    .ligne-patient { display: flex; align-items: center; gap: 1rem; padding: .9rem 1.1rem; border-top: 1px solid #f1f2f4; }
    .ligne-patient:first-child { border-top: none; }
    .ligne-patient .rang {
        width: 30px; height: 30px; flex: none; border-radius: 50%;
        background: #f3f4f6; color: #374151; font-weight: 700; font-size: .85rem;
        display: flex; align-items: center; justify-content: center;
    }
    .ligne-patient .rang.urgent { background: #fee2e2; color: #b91c1c; }
    .ligne-patient .nom { font-weight: 600; color: #111827; }
    .ligne-patient .meta { font-size: .82rem; color: #6b7280; }
    .ligne-patient .constantes { font-size: .8rem; }
    .attente-longue { color: #b45309; font-weight: 600; }
</style>
@endsection

@section('content')
<div class="container"><div class="page-inner">

    @php
        $reglePassage = (\App\Support\EtablissementContext::current()?->ordre_file ?? 'arrivee') === 'rendez_vous'
            ? 'rendez-vous, puis ordre d\'arrivée'
            : 'ordre d\'arrivée';
    @endphp

    <div class="page-header d-flex flex-wrap align-items-center gap-2">
        <div>
            <h3 class="fw-bold mb-0">Ma file d'attente</h3>
            <div class="small text-muted">
                {{ $enAttente->count() }} en attente · {{ $enConsultation->count() }} en cours · {{ $terminees->count() }} vus aujourd'hui
            </div>
        </div>
    </div>

    {{-- ------------------------------------------------ En consultation --}}
    @if($enConsultation->isNotEmpty())
        <div class="card">
            <div class="card-header"><h4 class="card-title">En consultation</h4></div>
            <div class="card-body p-0">
                @foreach($enConsultation as $v)
                    <div class="ligne-patient">
                        <div class="flex-grow-1">
                            <div class="nom">{{ $v->patient->full_name }}</div>
                            <div class="meta">{{ $v->motif }} · appelé à {{ $v->appele_le?->format('H:i') }}</div>
                        </div>
                        <a href="{{ route('parcours.consultation.show', $v->consultation) }}" class="btn btn-primary btn-sm">Reprendre</a>
                        <form method="POST" action="{{ route('parcours.file.terminer', $v) }}">@csrf
                            <button class="btn btn-secondary btn-sm">Terminer</button></form>
                    </div>
                @endforeach
            </div>
        </div>
    @endif

    {{-- ------------------------------------------------ Le suivant --}}
    @php $suivant = $enAttente->first(); @endphp

    @if($suivant)
        @php $transactionSuivant = $suivant->consultation?->transaction; @endphp
        <div class="card {{ $suivant->urgence ? 'patient-urgence' : 'patient-suivant' }}">
            <div class="card-body d-flex flex-wrap align-items-center gap-3">
                <div class="flex-grow-1">
                    <div class="small text-uppercase fw-bold" style="letter-spacing:.06em; color:#6b7280">Patient suivant</div>
                    <h4 class="mb-1">
                        {{ $suivant->patient->full_name }}
                        <span class="text-muted fw-normal" style="font-size:.9rem">
                            {{ $suivant->patient->gender }}{{ $suivant->patient->age !== null ? ', ' . $suivant->patient->age . ' ans' : '' }}
                        </span>
                        @if($suivant->urgence)<span class="badge badge-danger">Urgence</span>@endif
                        @if($suivant->appointment)<span class="badge badge-light">RDV {{ $suivant->appointment->appointment_time?->format('H:i') }}</span>@endif
                    </h4>
                    <div class="meta mb-1">
                        {{ $suivant->motif }} ·
                        <span class="{{ $suivant->minutesAttente() > 45 ? 'attente-longue' : '' }}">attend depuis {{ $suivant->minutesAttente() }} min</span>
                        @if($transactionSuivant && ! in_array($transactionSuivant->status, ['paid', 'approved'], true))
                            · <span class="text-warning">acte non encaissé</span>
                        @endif
                    </div>
                    <div class="constantes">@include('parcours.partials.constantes', ['c' => $suivant->derniereConstante])</div>
                </div>

                <div class="d-flex flex-column gap-2">
                    <form method="POST" action="{{ route('parcours.file.appeler', $suivant) }}">@csrf
                        <button class="btn btn-success"><i class="fa fa-bullhorn"></i> Appeler</button></form>
                    @can('parcours.dossier')
                        <a href="{{ route('parcours.dossier.show', $suivant->patient_id) }}" target="_blank" class="btn btn-secondary btn-sm">Dossier</a>
                    @endcan
                </div>
            </div>
        </div>
    @endif

    {{-- ------------------------------------------------ Le reste de la file --}}
    <div class="card">
        <div class="card-header">
            <h4 class="card-title mb-0">En attente <span class="badge badge-warning">{{ $enAttente->count() }}</span></h4>
            <span class="ms-auto small text-muted">Ordre fixé par l'accueil : urgences, puis {{ $reglePassage }}.</span>
        </div>
        <div class="card-body p-0">
            @forelse($enAttente->skip(1) as $index => $v)
                @php $transaction = $v->consultation?->transaction; @endphp
                <div class="ligne-patient">
                    <span class="rang {{ $v->urgence ? 'urgent' : '' }}">{{ $index + 2 }}</span>
                    <div class="flex-grow-1">
                        <div class="nom">
                            {{ $v->patient->full_name }}
                            <span class="text-muted fw-normal" style="font-size:.82rem">
                                {{ $v->patient->gender }}{{ $v->patient->age !== null ? ', ' . $v->patient->age . ' ans' : '' }}
                            </span>
                            @if($v->urgence)<span class="badge badge-danger">Urgence</span>@endif
                        </div>
                        <div class="meta">
                            {{ $v->motif }} ·
                            <span class="{{ $v->minutesAttente() > 45 ? 'attente-longue' : '' }}">{{ $v->minutesAttente() }} min</span>
                            @if($transaction && ! in_array($transaction->status, ['paid', 'approved'], true))
                                · <span class="text-warning">acte non encaissé</span>
                            @endif
                        </div>
                    </div>
                    <form method="POST" action="{{ route('parcours.file.appeler', $v) }}">@csrf
                        <button class="btn btn-secondary btn-sm">Appeler</button></form>
                </div>
            @empty
                @if(! $suivant)
                    <p class="text-muted text-center py-4 mb-0">Personne n'attend. Vous êtes à jour.</p>
                @endif
            @endforelse
        </div>
    </div>

    {{-- ------------------------------------------------ Vus aujourd'hui --}}
    @if($terminees->isNotEmpty())
        <details class="card">
            <summary class="card-header" style="cursor:pointer">
                <h4 class="card-title mb-0">Vus aujourd'hui ({{ $terminees->count() }})</h4>
            </summary>
            <ul class="list-group list-group-flush small">
                @foreach($terminees as $v)
                    <li class="list-group-item d-flex justify-content-between">
                        <span>{{ $v->terminee_le?->format('H:i') }} — {{ $v->patient->full_name }} · {{ $v->motif }}</span>
                        <a href="{{ route('consultation.show', $v->consultation) }}">Voir</a>
                    </li>
                @endforeach
            </ul>
        </details>
    @endif

</div></div>
@endsection
